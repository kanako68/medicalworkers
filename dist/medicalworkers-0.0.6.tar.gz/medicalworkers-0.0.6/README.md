# medicalworkers

一人の医療従事者につき、抱える国民の数を可視化するPython Packageです。
期間は2010年から2020年までの10年間で、最大4カ国まで可視化可能。

This Python Package visualizes the number of citizens held per healthcare professional.
The period is 10 years, from 2010 to 2020.
Up to 4 countries can be visualized.


## Example of use

```
pip install medicalworkers
python medicalworkers.py Japan France India 

```
